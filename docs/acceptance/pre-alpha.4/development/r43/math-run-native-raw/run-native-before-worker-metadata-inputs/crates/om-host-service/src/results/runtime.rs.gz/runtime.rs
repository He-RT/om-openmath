//! Dedicated immutable-result owner. No data parsing/evaluation/formatting runs on source/UI locks.
mod queries;
mod scratch;
use super::*;
use crate::protocol::{generated::*, validation};
use crate::tools::results::{FrozenInspection, InspectionContext, ResultInspectionService};
use crate::tools::scratch::{FrozenScratch, ScratchEvaluation};
use om_num::ctx::Clock;
pub use scratch::ScratchWorkerProbes;
use serde_json::{Value, json};
use std::{
    collections::{BTreeMap, VecDeque},
    sync::{Mutex, OnceLock, atomic::Ordering, mpsc},
    thread::{self, JoinHandle},
    time::Instant,
};
struct HostClock(Instant);
impl Clock for HostClock {
    fn now_ms(&self) -> f64 {
        self.0.elapsed().as_secs_f64() * 1000.0
    }
}
enum Message {
    RunOutputs {
        id: String,
        receipts: Vec<NativeKernelReceipt>,
        scope: Box<ReferenceScope>,
        token: Arc<AtomicBool>,
    },
    Accepted(Box<AcceptedKernelState>),
    Read {
        command: Box<NativeResultHostCommand>,
        scope: Box<ReferenceScope>,
        token: Arc<AtomicBool>,
    },
    Inspect {
        request: FrozenInspection,
        scope: Box<ReferenceScope>,
        token: Arc<AtomicBool>,
    },
    ScratchReady {
        id: String,
        scope: Box<ReferenceScope>,
        result: Result<Box<ScratchEvaluation>, String>,
        token: Arc<AtomicBool>,
    },
}
struct Entry {
    fingerprint: String,
    reply: NativeResultHostReply,
    cancel: Arc<AtomicBool>,
    scope: ReferenceScope,
}
struct State {
    entries: BTreeMap<String, Entry>,
    completed: VecDeque<String>,
}
/// Trusted fixture pause observes an actual running inspection; it grants no model/UI write access.
#[derive(Clone, Default)]
pub struct ResultWorkerProbes {
    /// Runs only on the real result thread after it marks the inspection running.
    pub before_query: Option<Arc<dyn Fn() + Send + Sync>>,
}
/// Bounded result worker plus compact original-ID request facts. Cancel is direct and independent.
pub struct ResultRuntime {
    sender: Mutex<Option<mpsc::SyncSender<Message>>>,
    scratch_sender: Mutex<Option<mpsc::SyncSender<scratch::Job>>>,
    state: Arc<Mutex<State>>,
    closing: Arc<AtomicBool>,
    owner: Mutex<Option<JoinHandle<()>>>,
}
fn request_id(command: &NativeResultHostCommand) -> &str {
    match command {
        NativeResultHostCommand::ResultManifest(b) => &b.request_id,
        NativeResultHostCommand::ResultInspect(b) => &b.request_id,
        NativeResultHostCommand::ResultStatus(b) => &b.request_id,
        NativeResultHostCommand::ResultRevoke(b) => &b.request_id,
        NativeResultHostCommand::ResultNotebookReferences(b) => &b.request_id,
    }
}
fn terminal(phase: &NativeResultHostReplyPhase) -> bool {
    matches!(
        phase,
        NativeResultHostReplyPhase::Completed
            | NativeResultHostReplyPhase::Cancelled
            | NativeResultHostReplyPhase::Failed
    )
}
fn base(scope: &ReferenceScope, id: &str) -> Result<NativeResultHostReply, String> {
    Ok(NativeResultHostReply {
        protocol_version: 1,
        request_id: id.into(),
        runtime_instance_id: scope.runtime.clone(),
        document_id: scope.document.clone(),
        document_generation: Serial::new(scope.generation)?,
        document_revision: Serial::new(scope.revision)?,
        execution_epoch: Serial::new(scope.execution_epoch)?,
        kernel_state_revision: Serial::new(scope.definition_revision)?,
        phase: NativeResultHostReplyPhase::Queued,
        binding: Nullable(None),
        payload: json!({}),
        error_code: Nullable(None),
    })
}
fn finish(state: &Mutex<State>, id: &str, value: Result<(Option<ResultBinding>, Value), String>) {
    let Ok(mut state) = state.lock() else { return };
    let Some(entry) = state.entries.get_mut(id) else {
        return;
    };
    if entry.cancel.load(Ordering::Acquire) {
        entry.reply.phase = NativeResultHostReplyPhase::Cancelled;
        entry.reply.error_code = Nullable(Some("CANCELLED".into()));
    } else {
        match value {
            Ok((binding, payload)) => {
                entry.reply.phase = NativeResultHostReplyPhase::Completed;
                entry.reply.binding = Nullable(binding);
                entry.reply.payload = payload;
            }
            Err(code) => {
                entry.reply.phase = NativeResultHostReplyPhase::Failed;
                entry.reply.error_code = Nullable(Some(code));
            }
        }
    }
    state.completed.push_back(id.into());
    while state.completed.len() > 32 {
        if let Some(id) = state.completed.pop_front()
            && let Some(old) = state.entries.get_mut(&id)
        {
            old.reply.binding = Nullable(None);
            old.reply.payload = json!({});
            old.reply.phase = NativeResultHostReplyPhase::Failed;
            old.reply.error_code = Nullable(Some("RESULT_DETAILS_EXPIRED".into()));
        }
    }
}
impl ResultRuntime {
    /// Known request identity across shared native operation namespaces, without queueing work.
    pub fn has_request(&self, id: &str) -> bool {
        self.state
            .lock()
            .is_ok_and(|state| state.entries.contains_key(id))
    }
    /// Create a dedicated result owner with host entropy, four queued messages and 32 requests.
    pub fn new() -> Result<Self, String> {
        Self::with_probes(ResultWorkerProbes::default())
    }
    /// Trusted test hook; no serialized request can configure this callback or pause behavior.
    pub fn with_probes(probes: ResultWorkerProbes) -> Result<Self, String> {
        Self::with_workers(probes, ScratchWorkerProbes::default())
    }
    /// A real independently scheduled scratch pause; no serialized request can install it.
    pub fn with_scratch_probes(probes: ScratchWorkerProbes) -> Result<Self, String> {
        Self::with_workers(ResultWorkerProbes::default(), probes)
    }
    fn with_workers(
        probes: ResultWorkerProbes,
        scratch_probes: ScratchWorkerProbes,
    ) -> Result<Self, String> {
        let mut key = [0; 32];
        getrandom::fill(&mut key).map_err(|_| "ENTROPY_UNAVAILABLE")?;
        let mut store =
            ResultStore::new(key, 64 * 1024 * 1024, 32).map_err(|_| "BUDGET_EXCEEDED")?;
        let mut inspection_key = [0; 32];
        getrandom::fill(&mut inspection_key).map_err(|_| "ENTROPY_UNAVAILABLE")?;
        let mut inspections = ResultInspectionService::new(inspection_key);
        let state = Arc::new(Mutex::new(State {
            entries: BTreeMap::new(),
            completed: VecDeque::new(),
        }));
        let closing = Arc::new(AtomicBool::new(false));
        let (sender, receiver) = mpsc::sync_channel::<Message>(4);
        let (scratch_sender, scratch_owner) =
            scratch::spawn(sender.clone(), state.clone(), scratch_probes)?;
        let replies = state.clone();
        let closed = closing.clone();
        let owner = thread::Builder::new()
            .name("openmath-result-worker".into())
            .spawn(move || {
                let clock: Arc<dyn Clock> = Arc::new(HostClock(Instant::now()));
                while let Ok(message) = receiver.recv() {
                    match message {
                        Message::ScratchReady {
                            id,
                            scope,
                            result,
                            token,
                        } => {
                            let context = Interrupt {
                                flag: token,
                                clock: Some(clock.clone()),
                                deadline_ms: Some(clock.now_ms() + 5000.),
                                steps_left: std::cell::Cell::new(4 * 1024 * 1024),
                            };
                            let payload =
                                std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                    if context.flag.load(Ordering::Acquire) {
                                        return crate::tools::results::failure(
                                            &id,
                                            &scope,
                                            "CANCELLED",
                                        );
                                    }
                                    match result {
                                        Ok(packet) => inspections.complete_scratch(
                                            *packet,
                                            &scope,
                                            clock.now_ms() as u64,
                                            &context,
                                        ),
                                        Err(code) => {
                                            crate::tools::results::failure(&id, &scope, &code)
                                        }
                                    }
                                }))
                                .map(|p| (None, p))
                                .map_err(|_| "RESULT_WORKER_PANIC".into());
                            finish(&replies, &id, payload);
                        }
                        Message::Accepted(accepted) => {
                            if closed.load(Ordering::Acquire) {
                                continue;
                            }
                            let context = Interrupt {
                                clock: Some(clock.clone()),
                                deadline_ms: Some(clock.now_ms() + 5000.),
                                ..Interrupt::default()
                            };
                            let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                // Cache capacity/codec failure changes availability only. Durable main math
                                // acceptance already exists and cannot be undone or replayed by this worker.
                                let _ = store.set_current(&accepted, &context);
                                if accepted.receipt().result_id.0.is_some()
                                    && let Ok(record) = StoredResult::capture(
                                        &accepted,
                                        CheckpointLimits::default(),
                                        &context,
                                    )
                                {
                                    let _ = store.register_recent(record);
                                }
                            }));
                        }
                        Message::RunOutputs {
                            id,
                            receipts,
                            scope,
                            token,
                        } => {
                            let ctx = Interrupt {
                                flag: token,
                                clock: Some(clock.clone()),
                                deadline_ms: Some(clock.now_ms() + 5000.),
                                steps_left: std::cell::Cell::new(4 * 1024 * 1024),
                            };
                            let result =
                                std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                    store.run_outputs(
                                        &receipts,
                                        &scope,
                                        clock.now_ms() as u64,
                                        &ctx,
                                    )
                                }))
                                .map_err(|_| "RESULT_WORKER_PANIC".to_owned())
                                .and_then(|r| r.map(|v| (None, v)).map_err(|e| e.to_string()));
                            finish(&replies, &id, result);
                        }
                        Message::Inspect {
                            request,
                            scope,
                            token,
                        } => {
                            let id = request.id().to_owned();
                            if let Ok(mut entries) = replies.lock()
                                && let Some(entry) = entries.entries.get_mut(&id)
                            {
                                entry.reply.phase = NativeResultHostReplyPhase::Running;
                            }
                            let context = Interrupt {
                                flag: token,
                                clock: Some(clock.clone()),
                                deadline_ms: Some(clock.now_ms() + 5000.),
                                steps_left: std::cell::Cell::new(4 * 1024 * 1024),
                            };
                            let result =
                                std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                    if let Some(probe) = &probes.before_query {
                                        probe();
                                    }
                                    inspections.execute(
                                        &request,
                                        InspectionContext {
                                            store: &store,
                                            scope: &scope,
                                            now: clock.now_ms() as u64,
                                            interrupt: &context,
                                        },
                                    )
                                }))
                                .map(|payload| (None, payload))
                                .map_err(|_| "RESULT_WORKER_PANIC".into());
                            finish(&replies, &id, result);
                        }
                        Message::Read {
                            command,
                            scope,
                            token,
                        } => {
                            let id = request_id(&command).to_owned();
                            if let Ok(mut entries) = replies.lock()
                                && let Some(entry) = entries.entries.get_mut(&id)
                            {
                                entry.reply.phase = NativeResultHostReplyPhase::Running;
                            }
                            let context = Interrupt {
                                flag: token,
                                clock: Some(clock.clone()),
                                deadline_ms: Some(clock.now_ms() + 5000.),
                                steps_left: std::cell::Cell::new(4 * 1024 * 1024),
                            };
                            let result =
                                std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                                    if let Some(probe) = &probes.before_query {
                                        probe();
                                    }
                                    queries::execute(
                                        &mut store,
                                        &command,
                                        &scope,
                                        clock.now_ms() as u64,
                                        &context,
                                    )
                                }))
                                .unwrap_or_else(|_| Err("RESULT_WORKER_PANIC".into()));
                            finish(&replies, &id, result);
                        }
                    }
                }
                // Scratch owns the only extra sender. Channel closure proves that worker has
                // finished/drained; join here, never while holding a source/control/UI lock.
                let _ = scratch_owner.join();
            })
            .map_err(|_| "INTERNAL_ERROR")?;
        Ok(Self {
            sender: Mutex::new(Some(sender)),
            scratch_sender: Mutex::new(Some(scratch_sender)),
            state,
            closing,
            owner: Mutex::new(Some(owner)),
        })
    }
    /// Retain an actual just-accepted snapshot on the independent worker; no source replay/IO here.
    pub fn accepted(&self, accepted: AcceptedKernelState) -> Result<(), String> {
        if self.closing.load(Ordering::Acquire) {
            return Err("HOST_CLOSING".into());
        }
        self.sender
            .lock()
            .map_err(|_| "INTERNAL_ERROR")?
            .as_ref()
            .ok_or("HOST_CLOSING")?
            .try_send(Message::Accepted(Box::new(accepted)))
            .map_err(|_| "BUDGET_EXCEEDED".into())
    }
    /// Native original run receipts only; issued references use the actual current Agent scope.
    pub(crate) fn run_outputs(
        &self,
        id: &str,
        receipts: Vec<NativeKernelReceipt>,
        scope: &ReferenceScope,
    ) -> Result<NativeResultHostReply, String> {
        let encoded = serde_json::to_vec(&receipts).map_err(|_| "INVALID_ARGUMENT")?;
        self.enqueue(id, &encoded, scope, |token| Message::RunOutputs {
            id: id.into(),
            receipts,
            scope: Box::new(scope.clone()),
            token,
        })
        .map_err(|error| {
            if error != "BUDGET_EXCEEDED" {
                return error;
            }
            match self.state.lock() {
                Ok(state) if state.entries.len() < 4096 => "RESULT_QUEUE_BUSY".into(),
                _ => "RESULT_NOT_AVAILABLE".into(),
            }
        })
    }
    /// Queue a strictly validated readonly command or read its original bounded status.
    pub fn command(
        &self,
        command: NativeResultHostCommand,
        scope: &ReferenceScope,
    ) -> Result<NativeResultHostReply, String> {
        scope.validate().map_err(|_| "STALE_DOCUMENT")?;
        if !scope.can_read {
            return Err("PERMISSION_DENIED".into());
        }
        let id = request_id(&command);
        if let NativeResultHostCommand::ResultStatus(_) = command {
            let state = self.state.lock().map_err(|_| "INTERNAL_ERROR")?;
            let entry = state.entries.get(id).ok_or("INVALID_REFERENCE")?;
            let original = &entry.scope;
            if original.runtime != scope.runtime
                || original.document != scope.document
                || original.generation != scope.generation
                || original.task != scope.task
                || original.task_generation != scope.task_generation
                || original.grant_revision != scope.grant_revision
                || original.metadata_revision != scope.metadata_revision
            {
                return Err("PERMISSION_DENIED".into());
            }
            return Ok(entry.reply.clone());
        }
        let encoded = serde_json::to_vec(&command).map_err(|_| "INVALID_ARGUMENT")?;
        self.enqueue(id, &encoded, scope, |token| Message::Read {
            command: Box::new(command.clone()),
            scope: Box::new(scope.clone()),
            token,
        })
    }
    /// Queue only a native-frozen original inspect intent. Caller scope must come from the actual
    /// Agent activation, never the manual task=None result command adapter.
    pub fn agent_inspect(
        &self,
        request: FrozenInspection,
        scope: &ReferenceScope,
    ) -> Result<NativeResultHostReply, String> {
        let id = request.id().to_owned();
        let encoded = serde_json::to_vec(&request.identity()).map_err(|_| "INVALID_ARGUMENT")?;
        self.enqueue(&id, &encoded, scope, |token| Message::Inspect {
            request,
            scope: Box::new(scope.clone()),
            token,
        })
    }
    fn enqueue(
        &self,
        id: &str,
        encoded: &[u8],
        scope: &ReferenceScope,
        message: impl FnOnce(Arc<AtomicBool>) -> Message,
    ) -> Result<NativeResultHostReply, String> {
        self.admit(id, encoded, scope, |token| {
            self.sender
                .lock()
                .map_err(|_| "INTERNAL_ERROR")?
                .as_ref()
                .ok_or("HOST_CLOSING")?
                .try_send(message(token))
                .map_err(|_| "BUDGET_EXCEEDED".into())
        })
    }
    /// Scratch evaluation is queued on its own CAS thread, independent of immutable inspection.
    pub fn agent_scratch(
        &self,
        request: FrozenScratch,
        scope: &ReferenceScope,
    ) -> Result<NativeResultHostReply, String> {
        if request.scope() != scope {
            return Err("PERMISSION_DENIED".into());
        }
        let id = request.id().to_owned();
        let encoded = serde_json::to_vec(&request.identity()).map_err(|_| "INVALID_ARGUMENT")?;
        self.admit(&id, &encoded, scope, |token| {
            self.scratch_sender
                .lock()
                .map_err(|_| "INTERNAL_ERROR")?
                .as_ref()
                .ok_or("HOST_CLOSING")?
                .try_send(scratch::Job {
                    request,
                    scope: Box::new(scope.clone()),
                    token,
                })
                .map_err(|_| "BUDGET_EXCEEDED".into())
        })
    }
    fn admit(
        &self,
        id: &str,
        encoded: &[u8],
        scope: &ReferenceScope,
        dispatch: impl FnOnce(Arc<AtomicBool>) -> Result<(), String>,
    ) -> Result<NativeResultHostReply, String> {
        scope.validate().map_err(|_| "STALE_DOCUMENT")?;
        if !scope.can_read {
            return Err("PERMISSION_DENIED".into());
        }
        if self.closing.load(Ordering::Acquire) {
            return Err("HOST_CLOSING".into());
        }
        let mut state = self.state.lock().map_err(|_| "INTERNAL_ERROR")?;
        let mut hasher = sha2::Sha256::new();
        use sha2::Digest;
        hasher.update(encoded);
        hasher.update(serde_json::to_vec(scope).map_err(|_| "INVALID_ARGUMENT")?);
        let fingerprint = format!("{:x}", hasher.finalize());
        if let Some(entry) = state.entries.get(id) {
            if entry.fingerprint != fingerprint {
                return Err("DUPLICATE_OPERATION".into());
            }
            return Ok(entry.reply.clone());
        }
        if state.entries.len() >= 4096
            || state
                .entries
                .values()
                .filter(|e| !terminal(&e.reply.phase))
                .count()
                >= 32
        {
            return Err("BUDGET_EXCEEDED".into());
        }
        let reply = base(scope, id)?;
        let token = Arc::new(AtomicBool::new(false));
        dispatch(token.clone())?;
        state.entries.insert(
            id.into(),
            Entry {
                fingerprint,
                reply: reply.clone(),
                cancel: token,
                scope: scope.clone(),
            },
        );
        Ok(reply)
    }
    /// Cancel a real pending inspection, independent from main computation and event queues.
    pub fn cancel(&self, id: &str) -> Option<bool> {
        let state = self.state.lock().ok()?;
        let entry = state.entries.get(id)?;
        if terminal(&entry.reply.phase) {
            return Some(false);
        }
        entry.cancel.store(true, Ordering::Release);
        Some(true)
    }
    /// Close admission/cancel first. Background caller joins the extracted owner after lock release.
    pub fn begin_close(&self) {
        self.closing.store(true, Ordering::Release);
        if let Ok(state) = self.state.lock() {
            for entry in state.entries.values().filter(|e| !terminal(&e.reply.phase)) {
                entry.cancel.store(true, Ordering::Release);
            }
        }
        if let Ok(mut sender) = self.sender.lock() {
            sender.take();
        }
        if let Ok(mut sender) = self.scratch_sender.lock() {
            sender.take();
        }
    }
    /// Extract worker for background join only; this method performs no blocking wait.
    pub fn take_thread(&self) -> Option<JoinHandle<()>> {
        self.begin_close();
        self.owner.lock().ok()?.take()
    }
}
impl Drop for ResultRuntime {
    fn drop(&mut self) {
        self.begin_close();
    }
}
/// Strict host-only result control DTO. It does not register an Agent tool or grant permissions.
pub fn decode_command(bytes: &[u8]) -> Result<NativeResultHostCommand, String> {
    static ROOT: OnceLock<Value> = OnceLock::new();
    let root = ROOT.get_or_init(|| {
        serde_json::from_str(include_str!(
            "../../../../docs/design/native-result-store.schema.json"
        ))
        .expect("checked result schema")
    });
    validation::decode(bytes, &root["$defs"]["NativeResultHostCommand"], root)
}

#[cfg(test)]
mod run_output_backpressure_tests {
    use super::*;
    use std::sync::{Condvar, atomic::AtomicBool};
    #[test]
    fn original_projection_retries_queue_pressure_but_reports_exhausted_lifetime() {
        let scope = ReferenceScope {
            runtime: "runtime".into(),
            document: "document".into(),
            generation: 1,
            revision: 0,
            execution_epoch: 0,
            snapshot_hash: "a".repeat(64),
            task: Some("task".into()),
            task_generation: 1,
            grant_revision: 1,
            config_revision: 0,
            definition_revision: 0,
            metadata_revision: 26,
            editor_state_hash: String::new(),
            execution_mode: true,
            can_read: true,
            can_preview: false,
            can_write: false,
        };
        let (arrived, wait) = mpsc::sync_channel(1);
        let gate = Arc::new((Mutex::new(false), Condvar::new()));
        let gate2 = gate.clone();
        let first = AtomicBool::new(true);
        let runtime = ResultRuntime::with_probes(ResultWorkerProbes {
            before_query: Some(Arc::new(move || {
                if first.swap(false, Ordering::AcqRel) {
                    arrived.send(()).unwrap();
                    let (lock, condition) = &*gate2;
                    let open = lock.lock().unwrap();
                    let (_guard, timeout) = condition
                        .wait_timeout_while(open, std::time::Duration::from_secs(10), |open| !*open)
                        .unwrap();
                    assert!(!timeout.timed_out());
                }
            })),
        })
        .unwrap();
        let query = |id: &str| {
            decode_command(&serde_json::to_vec(&json!({"type":"result_manifest","request_id":id,"root_result_id":"absent","offset":0,"limit":1})).unwrap()).unwrap()
        };
        runtime.command(query("held"), &scope).unwrap();
        wait.recv_timeout(std::time::Duration::from_secs(5))
            .unwrap();
        for i in 0..4 {
            runtime
                .command(query(&format!("queued-{i}")), &scope)
                .unwrap();
        }
        assert_eq!(
            runtime
                .run_outputs("original-projection", vec![], &scope)
                .err()
                .unwrap(),
            "RESULT_QUEUE_BUSY"
        );
        assert!(!runtime.has_request("original-projection"));
        let (lock, condition) = &*gate;
        *lock.lock().unwrap() = true;
        condition.notify_all();
        let deadline = Instant::now() + std::time::Duration::from_secs(15);
        let mut reply = loop {
            match runtime.run_outputs("original-projection", vec![], &scope) {
                Ok(reply) => break reply,
                Err(error) => {
                    assert_eq!(error, "RESULT_QUEUE_BUSY");
                    assert!(Instant::now() < deadline);
                    thread::yield_now();
                }
            }
        };
        let complete = |mut reply: NativeResultHostReply| {
            while !terminal(&reply.phase) {
                assert!(Instant::now() < deadline);
                thread::yield_now();
                reply = runtime
                    .command(
                        NativeResultHostCommand::ResultStatus(ResultStatus {
                            r#type: ResultStatusType::ResultStatus,
                            request_id: reply.request_id,
                        }),
                        &scope,
                    )
                    .unwrap();
            }
            reply
        };
        reply = complete(reply);
        assert_eq!(reply.phase, NativeResultHostReplyPhase::Completed);
        assert_eq!(reply.payload, json!({})); // Data-only empty projection, no evaluation callback.
        for i in 6..4096 {
            let reply = runtime
                .run_outputs(&format!("lifetime-{i}"), vec![], &scope)
                .unwrap();
            assert_eq!(complete(reply).phase, NativeResultHostReplyPhase::Completed);
        }
        assert_eq!(
            runtime
                .run_outputs("lifetime-exhausted", vec![], &scope)
                .err()
                .unwrap(),
            "RESULT_NOT_AVAILABLE"
        );
        assert!(!runtime.has_request("lifetime-exhausted"));
        runtime.take_thread().unwrap().join().unwrap();
    }
}
